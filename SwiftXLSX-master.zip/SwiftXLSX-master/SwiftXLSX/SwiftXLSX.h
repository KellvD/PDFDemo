//
//  SwiftXLSX.h
//  SwiftXLSX
//
//  Created by Carl Wieland on 4/28/17.
//  Copyright © 2017 Datum. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SwiftXLSX.
FOUNDATION_EXPORT double SwiftXLSXVersionNumber;

//! Project version string for SwiftXLSX.
FOUNDATION_EXPORT const unsigned char SwiftXLSXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftXLSX/PublicHeader.h>


