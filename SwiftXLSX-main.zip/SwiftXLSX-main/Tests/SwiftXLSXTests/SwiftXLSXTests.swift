import XCTest
@testable import SwiftXLSX

final class SwiftXLSXTests: XCTestCase {
    
    
    func testExample() throws {
        XCTAssertEqual(SwiftXLSX.test(), true)
    }
    
//    func testPerformance() throws {
//        self.measure {
//            _ = SwiftXLSX.test()
//        }
//    }
}
